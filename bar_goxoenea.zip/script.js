// Funcionalidades básicas
document.getElementById('year').textContent = new Date().getFullYear();

const navToggle = document.getElementById('nav-toggle');
const mainNav = document.getElementById('main-nav');
navToggle.addEventListener('click', () => {
  const open = mainNav.style.display === 'flex';
  mainNav.style.display = open ? 'none' : 'flex';
  navToggle.setAttribute('aria-expanded', String(!open));
});

const reserveForm = document.getElementById('reserve-form');
if (reserveForm) {
  reserveForm.addEventListener('submit', (e) => {
    alert('Gracias — tu solicitud de reserva se está enviando. Te confirmaremos cuanto antes.');
  });
}
