BAR GOXOENEA - Archivos del sitio web
-------------------------------
Contenido:
- index.html
- styles.css
- script.js
- /images/  (aquí van tu logo y fotos)
- /files/   (aquí puedes poner carta completa en PDF)
- README.txt (este archivo)

Instrucciones rápidas:
1) Logo:
   - Si tienes un logo, súbelo a la carpeta images/ con el nombre 'logo.png'.
   - Si tu logo tiene otro nombre o formato (ej: logo.svg), reemplaza images/logo.png por tu archivo o cambia el src en index.html.

2) Fotos:
   - Sustituye images/hero-placeholder.jpg y images/photo1.jpg... por tus fotos reales.
   - Si no tienes fotos, puedes usar imágenes libres (Unsplash, Pexels).

3) Formularios:
   - El formulario de reservas y el de newsletter están apuntando a Formspree con 'your-form-id'.
   - Opciones:
     a) Crear una cuenta gratis en Formspree y reemplazar 'your-form-id' por tu ID.
     b) Si prefieres Netlify Forms, despliega en Netlify y añade data-netlify="true" al form en index.html.
     c) También puedes usar Google Forms (embed).

4) Mapa:
   - Reemplaza el src del iframe del mapa por el enlace 'Embed' de Google Maps de tu localización.

5) Publicar (3 opciones sencillas):
   Opción A — GitHub Pages (gratis):
     - Crea una cuenta en github.com si no tienes.
     - Crea un nuevo repositorio y sube todos los archivos.
     - En Settings -> Pages activa GitHub Pages en la rama main.
   Opción B — Netlify (muy fácil):
     - Crea cuenta en netlify.com y "New site from Git" o arrastra la carpeta al panel de drag & drop.
   Opción C — FTP / hosting:
     - Sube los archivos al hosting del dominio con tu panel o FTP.

6) ¿Quieres que yo lo suba por ti?
   - Si quieres, puedo preparar el repositorio listo para GitHub Pages o ayudarte a desplegar en Netlify. Dime si quieres que lo haga y facilita acceso temporal (si prefieres hacerlo tú, te doy instrucciones paso a paso).

Notas:
- Revisa y personaliza textos: dirección, teléfono y horarios.
- Si necesitas que personalice la carta completa o que convierta la web en un repo de GitHub y lo suba por ti, dime y lo hago.
